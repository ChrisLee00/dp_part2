from django.apps import AppConfig


class UserinforConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'UserInfor'
