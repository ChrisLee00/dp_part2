from django.http import HttpResponse
from django.shortcuts import redirect
from UserInfor import models 
 
	
	
from django.shortcuts import render
 
def index(request):
    print(request.COOKIES.get('is_login'))
    status = request.COOKIES.get('is_login') # 收到浏览器的再次请求,判断浏览器携带的cookie是不是登录成功的时候响应的 cookie
    if not status:
        return redirect('/signin/')
    return render(request, "index.html")
	
	
def signin(request):
    return render(request, 'signin.html')
	
def book(request):
    return render(request, 'book.html')
	
def event(request):
    return render(request, 'event.html')
	
def room(request):
    return render(request, 'room.html')
	
	
def add_user(request):
    books = models.UserInfo.objects.create(username='Tom', password='123') 
    return HttpResponse("<p>数据添加成功！</p>")
	
def login(request):
    if request.method == "GET":
        return render(request, "signin.html")
    username = request.POST.get("username")
    password = request.POST.get("pwd")

    user_obj = models.UserInfo.objects.filter(username=username, password=password)

    if not user_obj:
        return redirect("/signin/")
    else:
        ctx ={}
        ctx['rlt'] = username
        rep = render(request, "index.html", ctx)
        rep.set_cookie("is_login", True)
        return rep

def logout(request):
    rep = redirect('/signin/')
    rep.delete_cookie("is_login")
    return rep # 点击注销后执行,删除cookie,不再保存用户状态，并弹到登录页面
   

	
